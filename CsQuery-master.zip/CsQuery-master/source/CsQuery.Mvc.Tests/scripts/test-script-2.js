﻿// A comment
 
/* <reference path="dep1.js" />
 using dep2

 end of dependencies */

 // using dep4

var test;
var test2;