﻿###Architecture (notes)

Namespaces

CsQuery									
CsQuery.Engine							CSS selection engine
CsQuery.Engine.PseudoClassSelectors		Implemenation of mose pseudoclass selectors.
CsQuery.Implementation					Concrete classes
CsQuery.HtmlParser
CsQuery.StringScanner
CsQuery.EquationParser
CsQuery.ExtensionMethodsD:\projects\csharp\CsQuery-mvc\source\CsQuery\Documentation\Changes.md
CsQuery.ExtensionMethods.Forms			Include this to add form-posting specific extension methods
CsQuery.ExtensionMethods.Internal
CsQuery.Promises						Promises API

Objects

CsQuery.CQ
CsQuery.Config							Static class for configuration
CsQuery.
CsQuery.Promises.When					Static factory for promises