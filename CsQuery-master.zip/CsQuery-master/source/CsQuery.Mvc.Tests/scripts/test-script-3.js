﻿/* 
using dep5 nocombine
<reference path="dep6-{version}.js" nocombine>

end of dependencies */

var script3;
