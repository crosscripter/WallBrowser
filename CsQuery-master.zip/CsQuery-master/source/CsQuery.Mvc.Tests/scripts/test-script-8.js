/// <reference path="~/scripts/dep8.js" />
/// <reference path="sub-lib/dep9.js" />
/// <reference path="dep10.js" />

var script8;
