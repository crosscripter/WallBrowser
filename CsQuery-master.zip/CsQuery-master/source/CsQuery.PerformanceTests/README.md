## CsQuery Test Runner - What Is This?

8/8/2012

This is console application that runs a series of performance tests to compare CsQuery's performance with HtmlAgilityPack + Fizzler. It will produce output in an `output` subfolder of the current exe location (or the project if running interactively).