﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Text;
using System.Reflection;
using System.IO;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using Assert = NUnit.Framework.Assert;
using Description = NUnit.Framework.DescriptionAttribute;
using TestContext = Microsoft.VisualStudio.TestTools.UnitTesting.TestContext;
using CsQuery;
using CsQuery.Utility;
using CsQuery.ExtensionMethods.Xml;

namespace CsQuery.Tests.ExtensionMethods
{
    // Not Implemented
    //[TestFixture, TestClass]
    //public class Xml: CsQueryTest
    //{


    //    [TestMethod, Test]
    //    public void ToXml()
    //    {
    //        var dom = TestDom("TestHtml");
    //        var xml = dom.Document.ToXml();

    //        StringWriter stringWriter = new StringWriter();
    //        XmlTextWriter xmlTextWriter = new XmlTextWriter(stringWriter);

    //        xml.WriteTo(xmlTextWriter);



    //    }


    
    //}

}