﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsQuery
{
    /// <summary>
    /// A marker interface for CDATA elements.
    /// </summary>

    public interface IDomCData : IDomSpecialElement
    {

    }

}
