﻿
### Important Differences from jQuery

##### Option Groups

jQuery and some browsers consider the first member of an option group to be selected, even if it is not explicitly marked as such. This behaviour has not been implemented.

